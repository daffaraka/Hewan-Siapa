

<?php $__env->startSection('judul','Laporan'); ?>
<?php $__env->startSection('content'); ?>

<div class="container p-5">
    <div class="row p-3">
        <div class="col-md-12 mb-3">
            <h2 class="text-dark text-center">Laporan Adopsi</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-dark m-3 ml-1 pull-right" href="<?php echo e(route('laporan.exportAdopsi')); ?>">Export Excel </a>
        </div>
        <div class="col-md-12">
            <table class="table bg-light rounded">
                <thead>
                    <tr class="table-primary">
                        <th> Nama Post </th>
                        <th> Owner Post </th>
                        <th> Pengaju Adopsi </th>
                        <th> Identitas Hewan </th>
                        <th> Waktu Transaksi </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $laporanAdopsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->LTA_nama_post); ?></td>
                        <td><?php echo e($data->LTA_nama_owner_post); ?></td>
                        <td><?php echo e($data->LTA_nama_pengaju); ?></td>
                        <td> <label class="badge badge-success"><?php echo e($data->LTA_jenis_hewan); ?> </label> - 
                             <label class="badge badge-info"> <?php echo e($data->LTA_ras_hewan); ?></label> </td>
                        <td><?php echo e($data->created_at); ?></td>
                    </tr>
                       
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/admin/dashboard/laporan/laporanAdopsi.blade.php ENDPATH**/ ?>