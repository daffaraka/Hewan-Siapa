
<?php echo $__env->make('frontend.partials-front-end.header-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('judul','Profil'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container" style="font-family: Montserrat">
        <div class="row">
            <div class="col-md-3 col-xl-4">
                <?php echo $__env->make('frontend.profile.partials.sidebar-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="col-md-8">
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="account" role="tabpanel">

                        <div class="card">
                            <div class="card-header">
                                <div class="card-actions float-right">
                                    <div class="dropdown show">
                                        <a href="#" data-toggle="dropdown" data-display="static">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-horizontal align-middle">
                                                <circle cx="12" cy="12" r="1"></circle>
                                                <circle cx="19" cy="12" r="1"></circle>
                                                <circle cx="5" cy="12" r="1"></circle>
                                            </svg>
                                        </a>

                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="#">Action</a>
                                            <a class="dropdown-item" href="#">Another action</a>
                                            <a class="dropdown-item" href="#">Something else here</a>
                                        </div>
                                    </div>
                                </div>
                                <h3 class="card-title mb-0">Permintaan pemacakan hewan anda</h3>
                            </div>
                        
                            <div class="row">
                                <div class="col-md-12 m-0">
                                    <div class="list-group">
                                        <?php if(count($permintaanPemacakan) == 0): ?>
                                        <div class="d-flex w-100 justify-content-between">
                                            <h5 class="mb-1">Tidak ada data</h5>
                                        </div>

                                        <?php else: ?>

                                            <?php $__currentLoopData = $permintaanPemacakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <img src="<?php echo e(asset('storage/post/pemacakan/pengajuan/'.$data->TM_gambar)); ?>"
                                                        class="w-100 mt-2 mb-2 ml-2 rounded"></a>
                                                    </div>


                                                        <div class="col mt-2">
                                                            <form action="<?php echo e(route('profile.terimaPemacakan',$data->id)); ?> )" method="POST" enctype="multipart/form-data">
                                                                <a href="#" class="list-group-item list-group-item-action">
                                                                    <div class="d-flex w-100 justify-content-between">
                                                                    <h5 class="mb-1"><?php echo e($data->TM_nama_post); ?></h5>
                                                                    <small><?php echo e($data->created_at->diffForHumans()); ?></small>
                                                                    </div>
                                                                    <p class="mb-1"><?php echo e($data->status_adopsi); ?></p>
                                                                    <p class="mb-1"><?php echo e($data->TM_jenis_hewan_pengaju); ?></p>
                                                                    <p class="mb-1"><?php echo e($data->TM_ras_hewan_pengaju); ?></p>
                                                                    <label class="badge-info p-1 pl-2 pr-2 rounded"><?php echo e($data->TM_nama_pengaju); ?></label>
                                                                </a>
                                                                <button type="submit" class="btn btn-lg btn-outline-info mt-4">Terima</button>
                                                                <a href="<?php echo e(route('profile.deletePermintaanPemacakan',$data->id)); ?>" class="btn btn-lg btn-outline-danger mt-4">Tolak</a>
                                                            </form>
                                                        </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      
                                        <?php endif; ?>
                                      
                                    </div>
                                </div>
                            </div>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/profile/user/Pemacakan-permintaan.blade.php ENDPATH**/ ?>