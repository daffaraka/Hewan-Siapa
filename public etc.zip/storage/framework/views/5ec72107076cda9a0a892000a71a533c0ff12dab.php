<?php $__env->startSection('content'); ?>
<div class="container" style="font-family: Montserrat;">
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="text-center mt-5">
                <h2> Show User</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary ml-5" href="<?php echo e(route('user.index')); ?>"> Back</a>
            </div>
        </div>
    </div>
    
    
    <div class="row p-5 bg-dark text-light m-5">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                Name:
                <?php echo e($user->name); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
               Email:
                <?php echo e($user->email); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                Roles:
                <?php if(!empty($user->getRoleNames())): ?>
                    <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="badge badge-success"><?php echo e($v); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/admin/dashboard/user/user-show.blade.php ENDPATH**/ ?>