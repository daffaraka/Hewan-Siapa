<footer id="footer-front-end" class="bg-dark">
    <div class="brand-logo">
        <p>Hewan Siapa</p>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/partials-front-end/footer.blade.php ENDPATH**/ ?>