<div class="banner">
    <div class="container">
        <div class="row banner-box">
            <div class="col-md-4 text-box">
                <h2 class="text-box-header">Selamat Datang</h2>
                <p>Tempat untuk mendapatkan hewan peliharaan yang anda inginkan. Temukan dia diantara hewan lain.Jadilah orang yang berpartisipasi untuk mengadopsi mereka. </p> 
                <div class="btn btn-outline-primary btn-lg "> Find your pet</div>
            </div>
            <div class="col-1"></div>
            <div class="col-md-6 banner-content">
                <img src="<?php echo e(asset('assets/img/front-end/Freepik/8527-removebg-preview.png')); ?>" alt="" class="banner-image">
                <!-- <div class="banner-caption"> Tes</div> -->
                <!-- <div class="banner-caption"><p>Tes</p></div> -->
            </div>
            
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/partials-front-end/banner.blade.php ENDPATH**/ ?>