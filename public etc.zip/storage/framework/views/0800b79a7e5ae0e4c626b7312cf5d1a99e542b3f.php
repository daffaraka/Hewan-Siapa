

<?php $__env->startSection('judul','Temukan teman baru anda'); ?>
<?php echo $__env->make('frontend.partials-front-end.header-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<form class="form-inline my-2 my-lg-0 mr-4 pull-right" action="<?php echo e(route('hewan-siapa.searchAdopsi')); ?>" method="get" >
    <?php echo csrf_field(); ?>
    <input class="form-control mr-sm-2" type="search" name="pencarian" placeholder="Search" aria-label="Search">
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
</form>
  <div class="container-fluid"> <br> <br>
    <div class="row">
        <div class="col"></div>
        <div class="col-md-2 rounded" id="sidebar-box">
            <section id=sidebar>
                <div>
                    <h5 class="category-list p-1 border-bottom text-center" >Jenis Hewan</h5>
                    <ul>
                        <?php $__currentLoopData = $listJenisHewan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listHewan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="#" class="text-dark"><?php echo e($listHewan->nama_jenis_hewan); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div>
                    <h5 class="category-list p-1 border-bottom text-center">Umur</h5>
                    <ul>
                        <li><a href="#" class="text-dark">Kitten</a></li>
                        <li><a href="#" class="text-dark">Adult</a></li>
                        <li><a href="#" class="text-dark">Tua</a></li>
                    </ul>
                </div>
            </section>
        </div>
        
        <div class="col-md-9">
            <div class="product-hewan-list">
                <div class="container">
                    <div class="row">
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 post">
                            <a href="<?php echo e(route('hewan-siapa.showAdopsi',$data->id)); ?>">
                                <div class="post-pet">
                                    <img src="<?php echo e(asset('storage/post/adopsi/'.$data->nama_post_adopsi.'-'.$data->image_post_adps)); ?>"  class="post-image" alt="">
                                    <div class="identitas-hewan" id="identitas-hewan">
                                            <h4 class="m-0 ml-3 mt-2 font-weight-bold" style="letter-spacing: 0.5"><?php echo e($data->nama_post_adopsi); ?></h4>
                                            <h4 class="ml-3 font-weight-bold" style="letter-spacing: 0.5"><?php echo e($data->nama_ras_hewan); ?></h4>
                                       
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php echo e($listAdopsi->links()); ?>

            </div>
        </div>
        
    </div>
    
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/adopsi/front-end-search-adopsi.blade.php ENDPATH**/ ?>