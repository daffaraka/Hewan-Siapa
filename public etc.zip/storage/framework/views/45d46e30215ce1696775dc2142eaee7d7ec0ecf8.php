

<?php $__env->startSection('judul','Show product'); ?>
    <?php echo $__env->make('frontend.partials-front-end.header-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="card col-12 mt-5">
                <div class="row bg-dark">
                    <aside class="col-md-5 border-right">
                        <article class="gallery-wrap"> 
                        <div class="img-big-wrap p-3">
                            <div> 
                                <a href="#">
                                <img src="<?php echo e(asset('storage/post/adopsi/'.$detailAdopsi->nama_post_adopsi.'-'.$detailAdopsi->image_post_adps)); ?>"
                                 class="auto m-2 rounded"></a>
                            </div>
                        </div> <!-- slider-product.// -->
                        
                        </article> <!-- gallery-wrap .end// -->
                    </aside>
                    <aside class="col-md-7 text-light w-100">
                        <article class="card-body pt-3">
                            <h3 class="title mb-3"><?php echo e($detailAdopsi->nama_post_adopsi); ?></h3>
                            <dl class="item-property">
                            <dt>Description</dt>
                            <dd><p><?php echo e($detailAdopsi->deskripsi_post_adps); ?></p></dd>
                            </dl>
                            <dl class="param param-feature">
                            <dt>Ras</dt>
                            <dd><?php echo e($detailAdopsi->nama_ras_hewan); ?></dd>
                            </dl>  <!-- item-property-hor .// -->
                            <dl class="param param-feature">
                            <dt>Color</dt>
                            <dd>Brown</dd>
                            </dl>  <!-- item-property-hor .// -->
                            <dl class="param param-feature">
                            <dt>Lokasi</dt>
                            <dd>Klaten Selatan</dd>
                            </dl>  <!-- item-property-hor .// -->
        
                        
                            <hr>
                            

                         
                           <a href="<?php echo e(route('hewan-siapa.form-pengajuan-adopsi',$detailAdopsi->id)); ?>" onclick="showConfirmation<?php echo e($detailAdopsi->id); ?>" class="btn btn-lg btn-outline-light text-uppercase adoptConfirm"> <i class="fa fa-heart-o" aria-hidden="true"></i> Adopt now </a>
                          
                            <a href="<?php echo e(route('hewan-siapa.editAdopsi',$detailAdopsi->id)); ?>" class="btn btn-lg btn-primary text-uppercase"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit </a>
                            <a href="#" class="btn btn-lg btn-warning text-uppercase"> <i class="fa fa-question-circle" aria-hidden="true"></i> Faq</a>
                        </article> <!-- card-body.// -->
                    </aside> <!-- col.// -->
                </div> <!-- row.// -->
            </div> <!-- card.// -->
        </div>
    </div>
    
  
<br><br><br>

<?php $__env->startSection('script'); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>   
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>

<script>
    function confirmDelete(item_id) {
        swal({
             title: 'Apakah Anda Yakin?',
              text: "Anda Tidak Akan Dapat Mengembalikannya!",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
        })
            .then((willDelete) => {
                if (willDelete) {
                    $('#'+item_id).submit();
                } else {
                    swal("Cancelled Successfully");
                }
            });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/adopsi/show-adopsi.blade.php ENDPATH**/ ?>