

<?php $__env->startSection('judul','Beranda'); ?>
<?php echo $__env->make('frontend.partials-front-end.header-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('frontend.partials-front-end.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-caption mt-5">
        <div class="caption">
            <p>This is our friend who are looking for new friend and home</p>
        </div>
    </div>

    <div class="container mb-5">
        <div class="row">

            <?php if(count($getRandomAdopsi)==null): ?>
                <div class="col-md-12">
                    <h1>Tidak Ada Data</h1>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $getRandomAdopsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $random): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 post">
                    <a href="<?php echo e(route('hewan-siapa.showAdopsi',$random->id)); ?>">
                        <div class="post-pet">
                            <img src="<?php echo e(asset('storage/post/adopsi/'.$random->nama_post_adopsi.'-'.$random->image_post_adps)); ?>"  class="post-image" alt="">
                            <h3 class="m-3 text-center font-weight-bold" style="letter-spacing: 0.5"><?php echo e($random->nama_post_adopsi); ?></h3>
                        </div>
                    </a>
                </div>
            
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

           
        
            <div class="col-md-3 post">
                <a href="<?php echo e(route('hewan-siapa.listAdopsi')); ?>">
                    <div class="post-pet bg-dark">
                        <div class="card h-100 bg-transparent text-light">
                            <h4 class="text-center h-100 mt-5">Ada lebih dari puluhan calon peliharaan yang bisa kamu adopsi! </h4>
                        </div>
                    </div>
                </a>
            </div>

            
        </div>
    </div>

    <div class="container mt-5">
        <div class="row banner-box">
            <div class="col-md-4 banner-content">
                <img src="<?php echo e(asset('assets/img/front-end/Freepik/cat-in-love.jpg')); ?>" alt="" class="banner-image w-75 mx-auto d-block">
            </div>
            <div class="col-md-8 text-box">
                <h2 class="text-box-header">Temukan Pasangan Hewan Anda</h2>
                <p>Tidak perlu khawatir lagi untuk menemukan pasangan untuk hewan anda. Hewan Siapa menyediakan fitur untuk mencari pasangan untuk hewan anda. Pastikan anda mempunyai hewan peliharan terlebih dahulu.</p> 
                <a href="<?php echo e(route('hewan-siapa.listPemacakan')); ?>">
                <div class="btn btn-outline-info btn-lg"> <i class="fa fa-heart-o"></i> Match your pet</div>
                </a>
            </div>
        </div>  
    </div>

    


    <?php $__env->startSection('script'); ?>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>   
    <script >
		Swal.fire({
		  icon: 'success',
		  title: 'Hewan Siapa',
          text: 'Temukan calon hewan anda disini',
		  showConfirmButton: true,
		  timer: 5000,

		})
    </script>
    
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/hewansiapa.blade.php ENDPATH**/ ?>