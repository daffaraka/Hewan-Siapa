

<?php $__env->startSection('judul', 'Daftar Jenis Hewan'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12" style="padding: 20px">
    <?php echo $__env->make('admin.flash.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <a button type="button" href="<?php echo e(route('jenishewan.create')); ?>" class="btn btn-primary" style="margin-bottom: 10px; margin-left:15px;"> Buat Baru</a>
    <select name="filter" id="" class="form-control" style="width: 100px; float: right; margin-rigth:50px;">
        <option value="">Filter</option>
        <option value="">Nama a-z</option>
        <option value="">Nama z-a</option>
    </select>
    
    <div class="col-md-12">
        <table class="table"style="background-color: white">
            <tbody >
                <thead>
                    <tr>
                        <th>Jenis Hewan</th>
                        <th>Action</th>
                    </tr>
                </thead>
                
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <tr>
                    <td> <?php echo e($d->nama_jenis_hewan); ?> </td>
                    <td>
                        <a href="jenishewan/<?php echo e($d->id); ?>/edit" class="btn btn-success">Edit</a>
                        <a href="jenishewan/delete/<?php echo e($d->id); ?>" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
            </tbody>
            
        </table>
        <?php echo e($data->links()); ?>

    </div>
   
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/admin/jenis-hewan/jenis-hewan-index.blade.php ENDPATH**/ ?>