


<?php $__env->startSection('judul','Update Jenis Hewan'); ?>
<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row" style="padding: 20px">
       
        <div class="col-md-8">
            <form action="<?php echo e(route('jenishewan.update', $data->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nama_jenis_hewan">Update Nama Jenis Hewan</label>
                    <input type="text" name="nama_jenis_hewan" id="nama_jenis_hewan" class="form-control" value="<?php echo e($data->nama_jenis_hewan); ?>">
                </div>
                <div class="form-group" style="margin-top: 10px;">
                    <button class="btn btn-primary" type="submit"> Simpan </button>
                    <a href="<?php echo e(route('jenishewan.index')); ?>" class="btn btn-info" style="margin-left: 10px"> Kembali </a>
                </div>
            </form>
        </div>
       
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/admin/jenis-hewan/edit-jenis-hewan.blade.php ENDPATH**/ ?>