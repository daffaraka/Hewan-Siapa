

<?php $__env->startSection('judul','Buat Post Adopsi Baru'); ?>





<?php $__env->startSection('content'); ?>

    

    <?php echo $__env->make('admin.flash.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      
            
                <form action="<?php echo e(route('adopsi.update',$adopsi->id)); ?>" method="POST" enctype="multipart/form-data" class="col-md-12" >
                    <?php echo csrf_field(); ?>
                    <div class="container" style="padding: 10px">
                        <div class="row" style="padding: 20px;box-shadow: grey 0 0 3px; border-radius:5px;">
                            
                            <div class="col-md-5" style="margin-top:30px;">
                                <img id="preview-image-before-upload" src="<?php echo e(asset('storage/post/adopsi/'.$adopsi->nama_post_adopsi.'-'.$adopsi->image_post_adps)); ?>"
                                alt="preview image" style="height:250px; max-width:400px; max-height: 250px; display:block; margin:15px auto; padding: 10px; box-shadow : grey 1px 1px 2px">

                                <div class="input-group mb-3">
                                    
                                    <div class="input-group-prepend">
                                      <span class="input-group-text">Upload</span>
                                    </div>

                                    <div class="custom-file">
                                      <input type="file" class="custom-file-input <?php $__errorArgs = ['nama_post_adopsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image_post_adps" id="image_post_adps" >
                                      <label class="custom-file-label"></label>
                                    </div>
                                </div>                                  
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nama_post_adopsi"> Judul Postingan</label>
                                    <input type="text" name="nama_post_adopsi" id="nama_post_adopsi" 
                                    class="form-control <?php $__errorArgs = ['nama_post_adopsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($adopsi->nama_post_adopsi); ?>">
                                    <?php $__errorArgs = ['nama_post_adopsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="nama_post_adopsi"> Jenis Post</label>
                                    <input type="text" name="jenis_post" id="jenis_post" class="form-control <?php $__errorArgs = ['jenis_post'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($adopsi->jenis_post); ?>">
                                    <?php $__errorArgs = ['jenis_post'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="deskripsi_post"> Deskripsi Post</label>
                                    <textarea type="text" name="deskripsi_post_adps" id="deskripsi_post_adps" 
                                    cols="30" rows="5" class="form-control <?php $__errorArgs = ['deskripsi_post_adps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" ><?php echo e($adopsi->deskripsi_post_adps); ?></textarea>
                                    <?php $__errorArgs = ['deskripsi_post_adps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="lokasi_post_adps"> Lokasi </label>
                                    <input type="text" name="lokasi_post_adps" id="lokasi_post_adps" 
                                    class="form-control <?php $__errorArgs = ['lokasi_post_adps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($adopsi->lokasi_post_adps); ?>" >
                                    <?php $__errorArgs = ['lokasi_post_adps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="syarat_adopsi">Syarat Mengadopsi </label>
                                    <input type="text" name="syarat_adopsi" id="syarat_adopsi" class="form-control <?php $__errorArgs = ['syarat_adopsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($adopsi->syarat_adopsi); ?>">
                                    <?php $__errorArgs = ['syarat_adopsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="jenis_hewan_id">Jenis Hewan</label>
                                    <select name="jenis_hewan_id"
                                     id="jenis_hewan_id"
                                     selected="true"
                                      class="jenis_hewan form-control <?php $__errorArgs = ['jenis_hewan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                                        <option value="">Pilih Jenis Hewan</option>
                                        <?php $__currentLoopData = $jenisHewan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($data->id); ?>" type="text"><?php echo e($data->nama_jenis_hewan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="ras_hewan_id">Ras Hewan</label>
                                    <select name="ras_hewan_id" id="ras_hewan_id" class="ras_hewan form-control <?php $__errorArgs = ['ras_hewan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" >
                                        <option value="" selected disabled>Tentukan Jenis Hewan Terlebih dahulu</option>
                                        
                                        <select name="ras_hewan_id" id="ras_hewan_id" class="ras_hewan form-control"></select>
                                    </select>
                                </div>

                             
                                <button type="submit" class="btn btn-primary">Submit</button>

                            </div>
                        </div>
                    </div>
                        
                </form>
      
           
   
                <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
 
                <script type="text/javascript">
                      
                     // Show image sebelum upload 
                    $(document).ready(function (e) {
                    
                    
                        $('#image_post_adps').change(function(){
                                    
                            let reader = new FileReader();
                        
                            reader.onload = (e) => { 
                        
                            $('#preview-image-before-upload').attr('src', e.target.result); 
                            }
                        
                            reader.readAsDataURL(this.files[0]); 
                        
                        });
                    
                    });


                    // Dynamic Dropdown

                    // jQuery(document).ready(function ()
                    // {
                    //         jQuery('select[name="jenis_hewan_id"]').on('change',function(){
                    //         var jenishewan_ID = jQuery(this).val();
                    //         if(jenishewan_ID)
                    //         {
                    //             jQuery.ajax({
                    //                 url : 'create/getJenisHewan/' +jenishewan_ID,
                    //                 type : "GET",
                    //                 data: {'id':id}
                    //                 dataType : "json",
                    //                 success:function(data)
                    //                 {
                    //                     console.log(data);
                    //                     jQuery('select[name="ras_hewan_id"]').empty();
                    //                     jQuery.each(data, function(key,value){
                    //                     $('select[name="ras_hewan_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                    //                     });
                    //                 }
                    //             });
                    //         }
                    //         else
                    //         {
                    //             $('select[name="ras_hewan_id"]').empty();
                    //         }
                    //         });
                    // });

                    
                 

                        $(document).on('change','.jenis_hewan',function(){
                        // console.log("hmm its change");

                        var jenis_hewan_ID=$(this).val();
                        
                        // console.log(cat_id);
                        var div=$(this).parent().parent();

                        var op=" ";

                        $.ajax({
                            type:'get',
                            url:'edit/findRasHewanOnEdit',
                            data:{'id':jenis_hewan_ID},
                            success:function(data){
                                //console.log('success');

                                //console.log(data);

                                //console.log(data.length);
                                op+='<option value="0" selected disabled>Pilih Ras Hewan</option>';
                                for(var i=0;i<data.length;i++){
                                op+='<option value="'+data[i].id+'">'+data[i].nama_ras_hewan+'</option>';
                            }

                            div.find('.ras_hewan').html(" ");
                            div.find('.ras_hewan').append(op);
                            },
                            error:function(){

                            }
                        });
                    });

                  

                    


                    
                 
                </script>
              
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/admin/dashboard/adopsi/edit-adopsi.blade.php ENDPATH**/ ?>