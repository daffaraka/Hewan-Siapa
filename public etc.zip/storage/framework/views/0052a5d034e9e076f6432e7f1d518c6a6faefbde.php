

<?php $__env->startSection('judul','Temukan teman baru yaaaa'); ?>
<?php echo $__env->make('frontend.partials-front-end.header-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->make('admin.flash.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <form action="<?php echo e(route ('hewan-siapa.ajukan-adopsi',$adopsi->id)); ?>" method="POST" enctype="multipart/form-data">
            <div class="row m-0">
                <aside class="col-sm-5">
                    <article class="gallery-wrap p-0"> 
                    <div class="img-big-wrap p-3 text-dark">
                        <div class="p-2"> 
                           
                            <img src="<?php echo e(asset('storage/post/adopsi/'.$adopsi->nama_post_adopsi.'-'.$adopsi->image_post_adps)); ?>"
                             class="mb-5 rounded shadow w-100 h-auto" id="TA_gambar">
                            </a>
                             
                             <h3 class="title mb-3"> <label class="badge badge-dark p-3"><?php echo e($adopsi->nama_post_adopsi); ?></label> </h3>
                             <dl class="item-property">
                             <dt>Description</dt>
                             <dd><p><?php echo e($adopsi->deskripsi_post_adps); ?></p></dd>
                             </dl>
                             <dl class="param param-feature">
                             <dt>Ras</dt>
                             <dd><?php echo e($adopsi->nama_ras_hewan); ?></dd>
                             </dl>  <!-- item-property-hor .// -->
                             <dl class="param param-feature">
                             <dt>Color</dt>
                             <dd><?php echo e($adopsi->color); ?></dd>
                             </dl>  <!-- item-property-hor .// -->
                             <dl class="param param-feature">
                             <dt>Lokasi</dt>
                             <dd>Klaten Selatan</dd>
                             </dl>  <!-- item-property-hor .// -->
                        </div>
                    </div> <!-- slider-product.// -->
                    </article> <!-- gallery-wrap .end// -->
                </aside>
                <aside class="col-sm-7 text-light bg-dark rounded-right">
                    <article class="card-body pt-4">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label> <h4>Nama Anda</h4> </label>
                                <input type="text" class="form-control font-weight-bolder font-size-20" name="nama_pengaju" id="nama_pengaju" placeholder="Nama anda" value="<?php echo e(Auth::user()->name); ?>">
                                <small id="emailHelp" class="form-text">*Isi sesuai nama anda , contoh : Budi</small>
                            </div>
                            <div class="form-group">
                                <label><h4>Alamat</h4></label>
                                <input type="text" class="form-control" name="TA_alamat_pengaju" id="TA_alamat_pengaju" placeholder="Klaten Selatan,Wedi,Karanganom dll">
                                <small id="emailHelp" class="form-text">*Isi alamat anda, contoh : Klaten Selatan</small>
                            </div>
                            <div class="form-group">
                                <label><h4>Kontak yang bisa dihubungi</h4></label>
                                <input type="text" class="form-control" name="TA_contact_pengaju" id="TA_contact_pengaju" placeholder="0812 3456 789 atau email">
                                <small id="emailHelp" class="form-text">*Isi dengan kontak yang bisa dihubungi oleh pemilik</small>
                                <small id="emailHelp" class="form-text m-0">*Diperbolehkan mengisi dengan sosial media</small>

                            </div>
                            <div class="form-group">
                                <label><h4>Alasan Memilih Dia</h4></label>
                                <textarea type="text" class="form-control" name="TA_alasan_memilih" id="TA_alasan_memilih"> </textarea>
                                <small class="form-text">*Jelaskan mengapa anda ingin mengadopsi dia</small>

                            </div>
                              <div class="form-group mt-5">
                                  <div class="row">
                                    <button class="col-md-9 btn btn-block btn-lg btn-outline-light mr-3" onclick="alert" type="submit">Kirim Permintaan</button>
                                    <a href="<?php echo e(route('hewan-siapa.showAdopsi',$adopsi->id)); ?>" class="btn btn-lg btn-warning"> Kembali</a>
                                  </div>
                              </div>
                        <hr>
                        
                    </article> <!-- card-body.// -->
                </aside> <!-- col.// -->
            </div> <!-- row.// -->
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/adopsi/front-end-form-pengajuan-adopsi.blade.php ENDPATH**/ ?>