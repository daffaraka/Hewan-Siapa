

<?php $__env->startSection('judul','Buat List Jenis Hewan'); ?>

<?php $__env->startSection('content'); ?>


<div class="container">

    <div class="row">
       
        <div class="col-md-5" style="padding:30px">

            <?php echo $__env->make('admin.flash.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo Form::open(['route' => 'jenishewan.store']); ?>

            <?php echo Form::token(); ?>

            <div class="form-group">
                <?php echo Form::label('nama_jenis_hewan', 'Nama Jenis Hewan', ['class' => 'h5']); ?> 
                <?php echo Form::text('nama_jenis_hewan','', ['class' => 'form-control']); ?>

            </div>
                <?php echo Form::submit('Submit', ['class' => 'btn btn-primary'] ,); ?>

                <a class="btn btn-info" href="<?php echo e(route('jenishewan.index')); ?>">Kembali</a>
            <?php echo Form::close(); ?>

         
        </div>
    </div>
</div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/admin/jenis-hewan/create-jenis-hewan.blade.php ENDPATH**/ ?>