<header>
  <?php if(Route::has('login')): ?>
  <nav class="navbar bg-dark navbar-dark justify-content-end" id="first-navbar">
    <ul class="nav justify-content-end" style="padding: unset;">
      <?php if(Route::has('register')): ?>
      <li class="nav-item ">
        <a class="nav-link text-light p-0"  style="display:unset" href="<?php echo e(route('register')); ?>">Register</a>
      </li>
      <?php endif; ?>
      <li class="nav-item p-0">
          <a class="nav-link text-light p-0" style="display:unset" href="<?php echo e(route('login')); ?>">Login</a>
      </li>
    </ul>
  </nav>
  <?php endif; ?>
    
    <nav class="navbar navbar-expand-sm bg-light navbar-light shadow-sm" style="justify-content: space-between">
        <!-- <a class="navbar-brand" href="#">Logo</a> -->
        <ul class="navbar-nav" id="navbar-nav">
          <li class="nav-item">
            <a class="nav-link text-dark" href="<?php echo e(route('hewan-siapa.index')); ?>">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="list-adopsi.html">Find your pet</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="profile.html">Profile</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="product-anda.html">Product Anda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="detail-product.html">Detail Product Anda</a>
          </li>
        </ul>
        <form class="form-inline mt-3">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form>
     </nav>
</header><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/partials-front-end/header.blade.php ENDPATH**/ ?>