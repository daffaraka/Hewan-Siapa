

<?php $__env->startSection('judul','Temukan teman baru yaaaa'); ?>
<?php echo $__env->make('frontend.partials-front-end.header-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->make('admin.flash.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card" style="font-family: Montserrat;">
            <div class="row m-0">
                <aside class="col-sm-5">
                    <article class="gallery-wrap p-0"> 
                    <div class="img-big-wrap p-3 text-dark">
                        <div class="p-2"> 
                           
                            <img src="<?php echo e(asset('storage/post/pemacakan/'. $pemacakan->nama_post_pemacakan.'-'. $pemacakan->image_post_pm)); ?>"
                             class="mb-5 rounded shadow w-100 h-auto" id="TA_gambar">
                            </a>
                             
                             <h3 class="title mb-3"> <label class="badge badge-dark p-3"><?php echo e($pemacakan->nama_post_pemacakan); ?></label> </h3>
                             <dl class="item-property">
                             <dt>Description</dt>
                             <dd><p><?php echo e($pemacakan->deskripsi_post_pm); ?></p></dd>
                             </dl>
                             <dl class="param param-feature">
                             <dt>Ras</dt>
                             <dd><?php echo e($pemacakan->nama_ras_hewan); ?></dd>
                             </dl>  <!-- item-property-hor .// -->
                             <dl class="param param-feature">
                             <dt>Color</dt>
                             <dd><?php echo e($pemacakan->color); ?></dd>
                             </dl>  <!-- item-property-hor .// -->
                             <dl class="param param-feature">
                                <dt>Lokasi</dt>
                                <dd><?php echo e($pemacakan->lokasi_post_pm); ?></dd>
                             </dl>  <!-- item-property-hor .// -->
                             <dl class="param param-feature">
                                <dt>Kontak Pengirim</dt>
                                <dd  class="mt-2"> <a class="btn-lg btn-info " href="https://api.whatsapp.com/send?phone=<?php echo e($pemacakan->kontak_pemacakan); ?>"><i class="fa fa-whatsapp"></i> <?php echo e($pemacakan->kontak_pemacakan); ?> </a> </dd>
                            </dl>  <!-- item-property-hor .// -->
                        </div>
                    </div> <!-- slider-product.// -->
                    </article> <!-- gallery-wrap .end// -->
                </aside>

                <aside class="col-sm-7 text-light bg-dark rounded-right">
                    <article class="card-body">
                    <form action="<?php echo e(route('hewan-siapa.ajukan-Pemacakan',$pemacakan->id)); ?>"  method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-12 p-0">
                                <label> <h4>Foto Hewan anda</h4> </label>
                                <img id="preview-image-before-upload" src="https://www.riobeauty.co.uk/images/product_image_not_found.gif"
                                alt="preview image" style="height:250px; max-width:400px; max-height: 250px; display:block; margin:15px auto; padding: 10px;">
                
                                <div class="input-group mb-3">
                                    
                                    <div class="input-group-prepend">
                                      <span class="input-group-text">Upload</span>
                                    </div>
                
                                    <div class="custom-file">
                                      <input type="file" class="custom-file-input <?php $__errorArgs = ['TM_gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="TM_gambar" id="TM_gambar" >
                                      <label class="custom-file-label"></label>
                                    </div>
                                </div>                                  
                            </div>

                            <div class="form-group">
                                <label for="jenis_hewan_id"> <h4>Jenis Hewan</h4> </label>
                                <select name="jenis_hewan_id" id="jenis_hewan_id" selected="true" class="jenis_hewan form-control <?php $__errorArgs = ['jenis_hewan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                                    <option value="">Pilih Jenis Hewan</option>
                                    <?php $__currentLoopData = $jenisHewan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($data->id); ?>" type="text"><?php echo e($data->nama_jenis_hewan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
            
                            <div class="form-group mb-5">
                                <label for="ras_hewan_id"><h4>Ras Hewan</h4></label>
                                <select name="ras_hewan_id" id="ras_hewan_id" class="ras_hewan form-control <?php $__errorArgs = ['ras_hewan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" >
                                    <option value="" selected disabled>Tentukan Jenis Hewan Terlebih dahulu</option>
                                    <select name="ras_hewan_id" id="ras_hewan_id" class="ras_hewan form-control"></select>
                                </select>
                            </div>

                            
                            <div class="form-group">
                                <label> <h4>Nama Anda</h4> </label>
                                <input type="text" class="form-control font-weight-bolder font-size-20" name="TM_nama_pengaju" id="TM_nama_pengaju" placeholder="Nama anda" value="<?php echo e(Auth::user()->name); ?>" disabled>
                                <small id="emailHelp" class="form-text">*Isi sesuai nama anda , contoh : Budi</small>
                            </div>
                            <div class="form-group">
                                <label><h4>Alamat</h4></label>
                                <input type="text" class="form-control" name="TM_alamat_pengaju" id="TM_alamat_pengaju" placeholder="Klaten Selatan,Wedi,Karanganom dll">
                                <small id="emailHelp" class="form-text">*Isi alamat anda, contoh : Klaten Selatan</small>
                            </div>
                            <div class="form-group">
                                <label><h4>Kontak yang bisa dihubungi</h4></label>
                                <input type="text" class="form-control" name="TM_contact_pengaju" id="TM_contact_pengaju" placeholder="0812 3456 789 atau email" value="+62"> 
                                <small id="emailHelp" class="form-text">*Isi dengan kontak yang bisa dihubungi oleh pemilik</small>
                                <small id="emailHelp" class="form-text m-0">*Diperbolehkan mengisi dengan sosial media</small>

                            </div>
                            <div class="form-group">
                                <label><h4>Alasan Memilih Dia</h4></label>
                                <textarea type="text" class="form-control" name="TM_alasan_memilih" id="TM_alasan_memilih"> </textarea>
                                <small class="form-text">*Jelaskan mengapa anda ingin mengadopsi dia</small>

                            </div>

                              <div class="form-group mt-5">
                                  <div class="row">
                                    <button class="col-md-9 btn btn-block btn-lg btn-outline-light mr-3" onclick="alert" type="submit">Kirim Permintaan</button>
                                    <a href="<?php echo e(route('hewan-siapa.showAdopsi', $pemacakan->id)); ?>" class="btn btn-lg btn-warning"> Kembali</a>
                                  </div>
                              </div>
                            <hr>
                            
                    </form>
                    </article> <!-- card-body.// -->
                </aside> <!-- col.// -->
            </div> <!-- row.// -->
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/pemacakan/front-end-form-pengajuan-pemacakan.blade.php ENDPATH**/ ?>