<header>
  <?php if(auth()->guard()->guest()): ?>
    <?php if(Route::has('login')): ?>
    <nav class="navbar bg-dark navbar-dark justify-content-end" style="height: 50px;" id="first-navbar">
      <ul class="nav justify-content-end" style="padding: unset;">
        <?php if(Route::has('register')): ?>
        <li class="nav-item ">
          <a class="nav-link text-light p-0"  style="display:unset" href="<?php echo e(route('register')); ?>">Register</a>
        </li>
        <?php endif; ?>
        <li class="nav-item p-0">
            <a class="nav-link text-light p-0" style="display:unset" href="<?php echo e(route('login')); ?>">Login</a>
        </li>
      </ul>
    </nav>
    <?php endif; ?>

  <?php else: ?>
    <nav class="navbar bg-dark navbar-dark justify-content-end"  style="height: 50px;" id="first-navbar">
      
      <ul class="nav justify-content-end" style="padding: unset;">
        <?php if(Auth::user()->hasRole('admin|super-admin')): ?>
        <li class="nav-item text-light p-0">
          <a href="<?php echo e(route('dashboard.admin')); ?>" class="text-light">Dashboard admin</a>
        </li>
        <?php endif; ?>
       
        <li class="nav-item dropdown">
          <a id="navbarDropdown" class="nav-link dropdown-toggle text-light p-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
              <?php echo e(Auth::user()->name); ?>

          </a>
    
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
              <a class="dropdown-item w-auto" href="<?php echo e(route('profile.dashboard')); ?>" >Profil</a>
              <a class="dropdown-item w-auto" href="<?php echo e(route('profile.adopsi')); ?>" >Adopsi</a>
              <a class="dropdown-item w-auto" href="<?php echo e(route('profile.pemacakan')); ?>" >Pemacakan</a>
              <a class="dropdown-item w-auto" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                              document.getElementById('logout-form').submit();">
                  <?php echo e(__('Logout')); ?>

              </a>
    
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                  <?php echo csrf_field(); ?>
              </form>
             
          </div>
        </li>
      
      </ul>
    
    </nav>
   
  <?php endif; ?>
 
    
    <nav class="navbar navbar-expand-sm bg-light navbar-light shadow-sm justify-content-between">
        <!-- <a class="navbar-brand" href="#">Logo</a> -->
            <ul class="navbar-nav" id="navbar-nav">
              <li class="nav-item">
                <a class="nav-link text-dark" href="<?php echo e(route('hewan-siapa.index')); ?>">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-dark" href="<?php echo e(route('hewan-siapa.listAdopsi')); ?>">Find your pet</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-dark" href="<?php echo e(route('hewan-siapa.listPemacakan')); ?>">Match your pet</a>
              </li>
            </ul>
            
           
            
     </nav>
</header><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/partials-front-end/header-front-end.blade.php ENDPATH**/ ?>