
<?php echo $__env->make('frontend.partials-front-end.header-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('judul','Profil'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container" style="font-family: Montserrat">
        <?php echo $__env->make('admin.flash.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-md-3 col-xl-4">
                <?php echo $__env->make('frontend.profile.partials.sidebar-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="col-md-8">
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="account" role="tabpanel">

                        <div class="card">
                            <div class="card-header">
                                <div class="card-actions float-right">
                                    <div class="dropdown show">
                                        <a href="#" data-toggle="dropdown" data-display="static">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-horizontal align-middle">
                                                <circle cx="12" cy="12" r="1"></circle>
                                                <circle cx="19" cy="12" r="1"></circle>
                                                <circle cx="5" cy="12" r="1"></circle>
                                            </svg>
                                        </a>

                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="<?php echo e(route('hewan-siapa.createAdopsi')); ?>">Buat baru</a>
                                        </div>
                                    </div>
                                </div>
                                <h3 class="card-title mb-0 font-weight-bold" style="letter-spacing:0.1">Pengajuan pemacakan  anda</h3>
                            </div>
                        
                            <div class="row">
                                <div class="col-md-12 m-0">
                                    <div class="list-group">
                                        <?php if(count($statusPengajuan) == 0): ?>
                                        <div class=" w-100 text-center">
                                            <h5 class="m-5"> <label class="badge-info p-2 rounded">Anda belum mengirimkan permintaan pemacakan.</label> </h5>
                                        </div>

                                        <?php else: ?>

                                            <?php $__currentLoopData = $statusPengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($data->TM_konfirmasi == 'belum_dikonfirmasi'): ?>
                                                    <div class="row mb-1 mt-1">
                                                        <div class="col m-3">
                                                            
                                                                <div class="d-flex w-100 justify-content-between mt-2">
                                                                <h5 class="mb-1"><?php echo e($data->TM_nama_post); ?></h5>
                                                                <small><?php echo e($data->created_at->diffForHumans()); ?></small>
                                                                </div>
                                                                <p class="mb-1"> <label class="badge-warning rounded p-2 mt-2 mb-2">Belum dikonfirmasi</label> </p>
                                                                <h6 class="m-0">Anda telah mengajukan permintaan adopsi terhadap postingan milik <b><?php echo e($data->TM_nama_owner_post); ?> </b>. <br> </h6>
                                                                <h6>Silahkan menunggu konfirmasi.</h6>
                                                            
                                                        </div>
                                                    </div>

                                                <?php elseif($data->TM_konfirmasi == 'diterima'): ?>
                                                    <div class="row pl-3 pr-3 mb-1 mt-1">
                                                        <div class="col text-dark p-3">
                                                            
                                                                <div class="d-flex w-100 justify-content-between mt-2">
                                                                <h4 class="mb-1"><?php echo e($data->TM_nama_post); ?></h4>
                                                                <small><?php echo e($data->updated_at->diffForHumans()); ?></small>
                                                                </div>
                                                                <p class="mb-1"> <label class="badge-primary rounded p-2 mt-2 mb-2">Diterima </label></p>
                                                                <h6 class="m-0">Anda telah mengajukan permintaan adopsi terhadap postingan milik <b><?php echo e($data->TM_nama_owner_post); ?> </b>  . <br> </h6>
                                                                <h6>Owner telah setuju dengan permintaan anda. <br> Silahkan hubungi kontak  : <a class="btn btn-info p-1" href=""> <i class="fa fa-whatsapp"></i> <?php echo e($data->TM_contact_pengaju); ?></a> </h6>
                                                            
                                                        </div>
                                                    </div>
                                                <?php elseif($data->TM_konfirmasi == 'ditolak'): ?>
                                                    <div class="row pl-3 pr-3 mb-1 mt-1">
                                                        <div class="col mb-1 mt-1 bg-light">
                                                            
                                                                <div class="d-flex w-100 justify-content-between mt-2">
                                                                <h4 class="mb-1"><?php echo e($data->TM_nama_post); ?></h4>
                                                                <small clas><?php echo e($data->created_at->diffForHumans()); ?></small>
                                                                </div>
                                                                <p class="mb-1"> <label class="badge-danger rounded p-2 mt-2 mb-2">Ditolak </label></p>
                                                                <h6 class="m-0">Anda telah mengajukan permintaan adopsi terhadap postingan milik <b><?php echo e($data->TM_nama_owner_post); ?> </b>. <br> </h6>
                                                                <h6>Owner telah menolak pengajuan pemacakan anda. Silahkan mencari alternatif lain.</h6>
                                                            
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      
                                        <?php endif; ?>
                                      
                                    </div>
                                </div>
                            </div>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>   
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11">
           $(document).on('click', '.btn', function (e) {
                e.preventDefault();
                var id = $(this).data('id');
                Swal.fire({
                        title: "Are you sure!",
                        type: "error",
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Yes!",
                        showCancelButton: true,
                    },
                    function() {
                        $.ajax({
                            type: "GET",
                            data: {id:id},
                            url: "<?php echo e(url('/hewan-siapa/deleteAdopsi')); ?>" + id,
                            success: function (data) {
                                        //
                                }         
                        });
                });
            });
        </script>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/profile/user/pemacakan-pengajuan-anda.blade.php ENDPATH**/ ?>