

<?php $__env->startSection('judul','Buat post anda'); ?>
<?php echo $__env->make('frontend.partials-front-end.header-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.flash.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<form action="<?php echo e(route('hewan-siapa.storeAdopsi')); ?>" method="POST" enctype="multipart/form-data" class="col-md-12" >
    <?php echo csrf_field(); ?>
    <div class="container" style="padding: 10px">
        <div class="row" style="padding: 20px;box-shadow: grey 0 0 3px; border-radius:5px;">
            
            <div class="col-md-5" style="margin-top:30px;">
                <img id="preview-image-before-upload" src="https://www.riobeauty.co.uk/images/product_image_not_found.gif"
                alt="preview image" style="height:250px; max-width:400px; max-height: 250px; display:block; margin:15px auto; padding: 10px; box-shadow : grey 1px 1px 2px">

                <div class="input-group mb-3">
                    
                    <div class="input-group-prepend">
                      <span class="input-group-text">Upload</span>
                    </div>

                    <div class="custom-file">
                      <input type="file" class="custom-file-input <?php $__errorArgs = ['nama_post_adopsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image_post_adps" id="image_post_adps" >
                      <label class="custom-file-label"></label>
                    </div>
                </div>                                  
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="nama_post_adopsi"> Judul Postingan</label>
                    <input type="text" name="nama_post_adopsi" id="nama_post_adopsi" class="form-control <?php $__errorArgs = ['nama_post_adopsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                    <?php $__errorArgs = ['nama_post_adopsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="jenis_hewan_id">Jenis Hewan</label>
                    <select name="jenis_hewan_id" id="jenis_hewan_id" selected="true" class="jenis_hewan form-control <?php $__errorArgs = ['jenis_hewan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <option value="">Pilih Jenis Hewan</option>
                        <?php $__currentLoopData = $jenisHewan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($data->id); ?>" type="text"><?php echo e($data->nama_jenis_hewan); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="ras_hewan_id">Ras Hewan</label>
                    <select name="ras_hewan_id" id="ras_hewan_id" class="ras_hewan form-control <?php $__errorArgs = ['ras_hewan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" >
                        <option value="" selected disabled>Tentukan Jenis Hewan Terlebih dahulu</option>
                        <select name="ras_hewan_id" id="ras_hewan_id" class="ras_hewan form-control"></select>
                    </select>
                </div>
                <div class="row">
                    <div class="col-md-4 form-group">
                        <label for="size-hewan">Ukuran Hewan</label>
                        <select name="size-hewan" id="size-hewan" selected="true" class="jenis_hewan form-control <?php $__errorArgs = ['size-hewan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                            <option value="" hidden>Ukuran</option>
                            <?php $__currentLoopData = App\Models\Product\Adopsi::sizeHewan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($size); ?>" type="text"><?php echo e($size); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                        </select>
                    </div>

                    <div class="col-md-4 form-group">
                        <label for="color">Warna Hewan</label>
                        <select name="color" id="color" selected="true" class="jenis_hewan form-control <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                            <option value="" hidden>Warna</option>
                            <?php $__currentLoopData = App\Models\Product\Adopsi::warnaHewan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($warna); ?>" type="text"><?php echo e($warna); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-4 form-group">
                        <label for="umur-hewan">Umur Hewan</label>
                        <select name="umur-hewan" id="umur-hewan" selected="true" class="jenis_hewan form-control <?php $__errorArgs = ['umur-hewan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                            <option value="" hidden>Umur</option>
                            <?php $__currentLoopData = App\Models\Product\Adopsi::umurHewan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $umur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($umur); ?>" type="text"><?php echo e($umur); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                        </select>
                    </div>
                </div>
                

                <div class="form-group">
                    <label for="deskripsi_post"> Deskripsi Post</label>
                    <textarea type="text" name="deskripsi_post_adps" id="deskripsi_post_adps" cols="30" rows="5" class="form-control <?php $__errorArgs = ['deskripsi_post_adps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                    <?php $__errorArgs = ['deskripsi_post_adps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="lokasi_post_adps"> Lokasi </label>
                    <input type="text" name="lokasi_post_adps" id="lokasi_post_adps" class="form-control <?php $__errorArgs = ['lokasi_post_adps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" >
                    <?php $__errorArgs = ['lokasi_post_adps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="lokasi_post_adps"> Kontak Anda </label>
                    <input type="text" name="kontak_adopsi" id="kontak_adopsi" class="form-control <?php $__errorArgs = ['kontak_adopsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" value="+62">
                    
                    <?php $__errorArgs = ['lokasi_post_adps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="syarat_adopsi">Syarat Mengadopsi </label>
                    <input type="text" name="syarat_adopsi" id="syarat_adopsi" class="form-control <?php $__errorArgs = ['syarat_adopsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" >
                    <?php $__errorArgs = ['syarat_adopsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
             
                <button type="submit" class="btn btn-primary">Submit</button>
                <a class="btn btn-secondary" href="<?php echo e(route('hewan-siapa.index')); ?>" style="margin-left: 20px;">Kembali </a>

            </div>
        </div>
    </div>
        
</form>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/adopsi/front-end-create-adopsi.blade.php ENDPATH**/ ?>