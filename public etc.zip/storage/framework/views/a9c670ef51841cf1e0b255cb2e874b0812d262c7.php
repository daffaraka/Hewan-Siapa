

<?php $__env->startSection('judul','Beranda'); ?>
<?php echo $__env->make('frontend.partials-front-end.header-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="card p-5 bg-gray">

    <div class="card-body">

        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($data ): ?>
                
            <?php endif; ?>
            <p><?php echo e($data->nama_post_adopsi); ?></p>
            <img class="card-img-top" src=" <?php echo e(asset('storage/post/adopsi/'.$data->nama_post_adopsi.'-'.$data->image_post_adps)); ?>"
                                         style="height: 100px; max-width:100px; object-fit:cover; object-position:center;">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/search.blade.php ENDPATH**/ ?>