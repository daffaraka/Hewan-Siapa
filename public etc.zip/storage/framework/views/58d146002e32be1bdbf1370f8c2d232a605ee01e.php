
<?php echo $__env->make('frontend.partials-front-end.header-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('judul','Konfirmasi permintaan anda'); ?>

<?php $__env->startSection('content'); ?>


    
    <div class="container" style="font-family: Montserrat">
        <?php echo $__env->make('admin.flash.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-md-3 col-xl-4">
                <?php echo $__env->make('frontend.profile.partials.sidebar-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-8">
                <div class="card">
                    <h4 class="card-header bg-info text-light">Konfirmasi permintaan seseorang</h4>
                    <div class="card-body">

                        <form action="<?php echo e(route('hewan-siapa.beriKonfirmasi',$konfirmasiPermintaan->id)); ?> )" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <p class="card-text">Seseorang telah mengirim permintaan untuk mengadopsi hewan anda ! </p>
                            <p>  <b><?php echo e($konfirmasiPermintaan->TA_nama_pengaju); ?></b> tertarik dengan hewan yang anda kirim disini ,yaitu
                                <label class="badge-primary p-1 rounded"><?php echo e($konfirmasiPermintaan->TA_nama_post); ?></label><br>
                                Alasan dia tertarik dengan hewan anda ialah <?php echo e($konfirmasiPermintaan->TA_alasan_memilih); ?>,
                                Beri dia konfirmasi dan segera bertemu dengan pemilik baru hewan anda.
                                
                                <br> <br>
                                Contact dia segera : <b><?php echo e($konfirmasiPermintaan->TA_contact_pengaju); ?> </b> <br>
                            
                                    <button type="submit" class="btn btn-lg btn-outline-info mt-4">Terima</button>
                                    <a href="<?php echo e(route('hewan-siapa.deletePermintaanAdopsi',$konfirmasiPermintaan->id)); ?>" class="btn btn-lg btn-outline-danger mt-4">Tolak</a>
                        </form>
                         
                            
                            </b> 
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/profile/user/konfirmasi-adopsi.blade.php ENDPATH**/ ?>