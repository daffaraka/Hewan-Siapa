

<?php $__env->startSection('judul','Buat post anda'); ?>
<?php echo $__env->make('frontend.partials-front-end.header-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col"></div>
        <div class="col-md-2 rounded">
                <div>
                    <h5 class="category-list p-1 border-bottom text-center" >Jenis Hewan</h5>
                    <ul>
                        <?php $__currentLoopData = $listJenisHewan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listHewan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="#" class="text-dark"><?php echo e($listHewan->nama_jenis_hewan); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div>
                    <h5 class="category-list p-1 border-bottom text-center">Umur</h5>
                    <ul>
                        <li><a href="#" class="text-dark">Kitten</a></li>
                        <li><a href="#" class="text-dark">Adult</a></li>
                        <li><a href="#" class="text-dark">Tua</a></li>
                    </ul>
                </div>
        </div>
        <div class="col-md-9">
            <div class="product-hewan-list">
                <div class="container">
                    <div class="row">
                    <?php $__currentLoopData = $listPemacakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 post">
                            <a class="text-decoration-none" href="<?php echo e(route('hewan-siapa.showPemacakan',$data->id)); ?>">
                                <div class="post-pet">
                                    <img src="<?php echo e(asset('storage/post/pemacakan/'.$data->nama_post_pemacakan.'-'.$data->image_post_pm)); ?>"  class="post-image" alt="">
                                    <div class="identitas-hewan" id="identitas-hewan">
                                            <h5 class="m-2 font-weight-normal"><?php echo e($data->nama_post_pemacakan); ?></h5>
                                            <h5 class="m-2 font-weight-normal"><?php echo e($data->nama_jenis_hewan); ?></h5>
                                       
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php echo e($listPemacakan->links()); ?>

            </div>
        </div>
        
    </div>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout-front-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HewanSiapa\resources\views/frontend/pemacakan/list-pemacakan.blade.php ENDPATH**/ ?>