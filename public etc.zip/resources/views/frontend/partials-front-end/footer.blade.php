<footer id="footer-front-end" class="bg-dark">
    <div class="brand-logo">
        <p>Hewan Siapa</p>
    </div>
</footer>