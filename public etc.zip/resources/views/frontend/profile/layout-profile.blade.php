@extends('frontend.layout-front-end')

@include('frontend.partials-front-end.header-front-end');

@section('content')
    

@endsection