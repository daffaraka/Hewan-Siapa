<a href="#!" class="list-group-item list-group-item-action">
    <div class="row align-items-center">
      <div class="col-auto">
        <!-- Avatar -->
        <img alt="Image placeholder" src="{{("assets/img/theme/team-1.jpg")}}" class="avatar rounded-circle">
      </div>
      <div class="col ml--2">
        <div class="d-flex justify-content-between align-items-center">
          <div>
            <h4 class="mb-0 text-sm">John Snow</h4>
          </div>
          <div class="text-right text-muted">
            <small>2 hrs ago</small>
          </div>
        </div>
        <p class="text-sm mb-0">Let's meet at Starbucks at 11:30. Wdyt?</p>
      </div>
    </div>
  </a>
  <a href="#!" class="list-group-item list-group-item-action">
    <div class="row align-items-center">
      <div class="col-auto">
        <!-- Avatar -->
        <img alt="Image placeholder" src="{{asset('assets/img/theme/team-2.jpg')}}" class="avatar rounded-circle">
      </div>
      <div class="col ml--2">
        <div class="d-flex justify-content-between align-items-center">
          <div>
            <h4 class="mb-0 text-sm">John Snow</h4>
          </div>
          <div class="text-right text-muted">
            <small>3 hrs ago</small>
          </div>
        </div>
        <p class="text-sm mb-0">A new issue has been reported for Argon.</p>
      </div>
    </div>
  </a>
  <a href="#!" class="list-group-item list-group-item-action">
    <div class="row align-items-center">
      <div class="col-auto">
        <!-- Avatar -->
        <img alt="Image placeholder" src="assets/img/theme/team-3.jpg" class="avatar rounded-circle">
      </div>
      <div class="col ml--2">
        <div class="d-flex justify-content-between align-items-center">
          <div>
            <h4 class="mb-0 text-sm">John Snow</h4>
          </div>
          <div class="text-right text-muted">
            <small>5 hrs ago</small>
          </div>
        </div>
        <p class="text-sm mb-0">Your posts have been liked a lot.</p>
      </div>
    </div>
  </a>
  <a href="#!" class="list-group-item list-group-item-action">
    <div class="row align-items-center">
      <div class="col-auto">
        <!-- Avatar -->
        <img alt="Image placeholder" src="assets/img/theme/team-4.jpg" class="avatar rounded-circle">
      </div>
      <div class="col ml--2">
        <div class="d-flex justify-content-between align-items-center">
          <div>
            <h4 class="mb-0 text-sm">John Snow</h4>
          </div>
          <div class="text-right text-muted">
            <small>2 hrs ago</small>
          </div>
        </div>
        <p class="text-sm mb-0">Let's meet at Starbucks at 11:30. Wdyt?</p>
      </div>
    </div>
  </a>
  <a href="#!" class="list-group-item list-group-item-action">

    <div class="row align-items-center">
        <div class="col-auto">
          <!-- Avatar -->
          <img alt="Image placeholder" src="assets/img/theme/team-5.jpg" class="avatar rounded-circle">
        </div>
        <div class="col ml--2">
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <h4 class="mb-0 text-sm">John Snow</h4>
            </div>
            <div class="text-right text-muted">
              <small>3 hrs ago</small>
            </div>
          </div>
          <p class="text-sm mb-0">A new issue has been reported for Argon.</p>
        </div>
      </div>